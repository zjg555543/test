use crate::binary::Binary;

pub type QueryResponse = Binary;
